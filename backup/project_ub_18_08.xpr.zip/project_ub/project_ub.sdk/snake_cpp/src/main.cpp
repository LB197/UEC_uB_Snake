#include "point.h"
#include "snake.h"
#include "xgpio.h"
#include "xparameters.h"
#include "vga.h"
#include "xil_types.h"
#include "xtmrctr.h"
#include "xil_exception.h"
#include "xintc.h"

Sssssnake Snake;
Point Food;
unsigned short Score = 0;

XGpio gpio0;
XIntc InterruptController;
XTmrCtr DrawScreenTimer;

void Wait(u32 time) {
	for(u32 i = 0; i < time; i++);
}

void DrawScreen(){
	VGA_DrawRectangle(0, Food.PointX * SIZE, Food.PointY * SIZE, SIZE, SIZE, IMAGE_APPLE);
	VGA_DrawRectangle(1, Snake.HeadPosX * SIZE, Snake.HeadPosY * SIZE, SIZE, SIZE, IMAGE_GRASS);
	for(u8 i = 0; i <= Snake.TailNumber; i++) {
		VGA_DrawRectangle(i+2, Snake.TailX[i] * SIZE, Snake.TailY[i] * SIZE, SIZE, SIZE, IMAGE_BODY);
	}
}

void HardwareInit() {
	XGpio_Initialize(&gpio0, XPAR_GPIO_0_DEVICE_ID);
	XGpio_SetDataDirection(&gpio0, 1, 0xFFFFFFFF); // set BTN GPIO channel to All Input

	XTmrCtr_Initialize(&DrawScreenTimer, XPAR_AXI_TIMER_0_DEVICE_ID);

	//Initialize the interrupt controller driver so that
	//it's ready to use, specify the device ID that is generated in
	//xparameters.h
	XIntc_Initialize(&InterruptController, XPAR_INTC_0_DEVICE_ID);

	//Connect a device driver handler that will be called when an interrupt
	//for the device occurs, the device driver handler performs the specific
	//interrupt processing for the device

	XIntc_Connect(&InterruptController, XPAR_INTC_0_TMRCTR_0_VEC_ID,
					(XInterruptHandler)XTmrCtr_InterruptHandler,
					(void *)&DrawScreenTimer);

	//Start the interrupt controller such that interrupts are enabled for
	//all devices that cause interrupts, specific real mode so that
	//the timer counter can cause interrupts thru the interrupt controller.

	XIntc_Start(&InterruptController, XIN_REAL_MODE);

	//Enable the interrupt for the timer counter
	XIntc_Enable(&InterruptController, XPAR_INTC_0_TMRCTR_0_VEC_ID);

	//Initialize the exception table.
	Xil_ExceptionInit();

	//Register the interrupt controller handler with the exception table.
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
					(Xil_ExceptionHandler) XIntc_InterruptHandler,
					&InterruptController);


	//Enable non-critical exceptions.
	Xil_ExceptionEnable();

	//Setup the handler for the timer counter that will be called from the
	//interrupt context when the timer expires, specify a pointer to the
	//timer counter driver instance as the callback reference so the handler
	//is able to access the instance data

	XTmrCtr_SetHandler(&DrawScreenTimer, (XTmrCtr_Handler) DrawScreen, 0);

	//Enable the interrupt of the timer counter so interrupts will occur
	//and use auto reload mode such that the timer counter will reload
	//itself automatically and continue repeatedly, without this option
	//it would expire once only

	XTmrCtr_SetOptions(&DrawScreenTimer, 0,
				XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);

	//Set a reset value for the timer counter such that it will expire
	//eariler than letting it roll over from 0, the reset value is loaded
	//into the timer counter when it is started

	XTmrCtr_SetResetValue(&DrawScreenTimer, 0, 0xFFFFFF00);

	//Start the timer counter such that it's incrementing by default,
	//then wait for it to timeout a number of times

	XTmrCtr_Start(&DrawScreenTimer, 0);

	VGA_SetBackgroundColor(0xFFF);
}

int main() {

	bool GameOn = true;
	HardwareInit();


	while(GameOn) {
		Snake.MoveSnake();
		if(Snake.bCheckIfSnakeOnPoint(Food.PointX, Food.PointY)) {
			do {
				Food.Generate();
			} while(Snake.bCheckIfSnakeOnPoint(Food.PointX, Food.PointY));
			Snake.AddTail();
		}
		GameOn = !(Snake.bCheckIfTailHit());
	}
	return 0;
}
