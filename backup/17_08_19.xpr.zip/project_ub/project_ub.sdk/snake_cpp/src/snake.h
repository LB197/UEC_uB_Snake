#ifndef SNAKE_H_
#define SNAKE_H_
#include "xil_types.h"

#define SIZE	32
#define WIDTH 	25
#define HEIGHT 	18

enum Direction{UP, LEFT, DOWN, RIGHT};

class Sssssnake {
public:
	u32 HeadPosX;
	u32 HeadPosY;
	enum Direction eDirection;
	u32 TailX[32];
	u32 TailY[32];
	u32 TailNumber;

	Sssssnake();
	void MoveSnake();
	bool bCheckIfTailHit();
	bool bCheckIfSnakeOnPoint(u32 X, u32 Y);
	void AddTail();
	void CalcTail();
	void GetKey();
};

#endif /* SNAKE_H_ */
