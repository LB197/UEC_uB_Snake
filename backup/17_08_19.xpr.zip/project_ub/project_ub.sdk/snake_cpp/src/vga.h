#ifndef SRC_VGA_H_
#define SRC_VGA_H_
#include "xbasic_types.h"
#include "xil_types.h"

#define IMAGE_APPLE			0ULL
#define IMAGE_GRASS			1ULL
#define IMAGE_BODY			2ULL
#define IMAGE_HEAD_DOWN		3ULL
#define IMAGE_HEAD_LEFT		4ULL
#define IMAGE_HEAD_RIGHT	5ULL
#define IMAGE_HEAD_UP		6ULL

void VGA_SetBackgroundColor(u16 Color);
void VGA_DrawRectangle(u16 ObjectID, u64 X, u64 Y, u64 Width, u64 Height, u64 Image);
void VGA_DeleteRectangle(u16 ObjectID);

#endif /* SRC_VGA_H_ */
