#ifndef POINT_H_
#define POINT_H_
#include "xil_types.h"

class Point {
public:
	u32 PointX;
	u32 PointY;
	Point();
	void Generate();

};

#endif /* POINT_H_ */
