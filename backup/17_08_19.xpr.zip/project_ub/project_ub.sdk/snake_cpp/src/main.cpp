#include "point.h"
#include "snake.h"
#include "xgpio.h"
#include "xparameters.h"
#include "vga.h"
#include "xil_types.h"

Sssssnake Snake;
Point Food;
unsigned short Score = 0;
XGpio gpio0;

void Wait(u32 time) {
	for(u32 i = 0; i < time; i++);
}

void DrawScreen(){
	VGA_DrawRectangle(0, Food.PointX * SIZE, Food.PointY * SIZE, SIZE, SIZE, IMAGE_APPLE);
	VGA_DrawRectangle(1, Snake.HeadPosX * SIZE, Snake.HeadPosY * SIZE, SIZE, SIZE, IMAGE_GRASS);
	for(u8 i = 0; i <= Snake.TailNumber; i++) {
		VGA_DrawRectangle(i+2, Snake.TailX[i] * SIZE, Snake.TailY[i] * SIZE, SIZE, SIZE, IMAGE_BODY);
	}
}

int main() {

	bool GameOn = true;
	XGpio_Initialize(&gpio0, XPAR_GPIO_0_DEVICE_ID);
	XGpio_SetDataDirection(&gpio0, 1, 0xFFFFFFFF); // set BTN GPIO channel to All Input
	VGA_SetBackgroundColor(0xFFF);

	DrawScreen();
	Wait(10000000);
	while(GameOn) {
		Snake.MoveSnake();
		if(Snake.bCheckIfSnakeOnPoint(Food.PointX, Food.PointY)) {
			do {
				Food.Generate();
			} while(Snake.bCheckIfSnakeOnPoint(Food.PointX, Food.PointY));
			Snake.AddTail();
		}
		DrawScreen();
		Wait(1000000);
		GameOn = !(Snake.bCheckIfTailHit());
	}
	return 0;
}
