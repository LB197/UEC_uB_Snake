#include "point.h"
#include <stdlib.h>

#define SIZE	32
#define WIDTH 	25
#define HEIGHT 	18

Point::Point() {
	srand(5);
	Generate();
}

void Point::Generate() {
	PointX = rand() % WIDTH;
	PointY = rand() % HEIGHT;
}
