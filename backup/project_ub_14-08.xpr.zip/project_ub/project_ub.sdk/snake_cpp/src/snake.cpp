#include "snake.h"
#include "xgpio.h"

#define SIZE	32
#define WIDTH 	25
#define HEIGHT 	18

extern XGpio gpio1;

Sssssnake::Sssssnake() {
	HeadPosX = WIDTH/2;
	HeadPosY = HEIGHT/2;
	eDirection = RIGHT;
	TailX[0] = WIDTH/2 - 1;
	TailY[0] = HEIGHT/2;
	TailNumber = 0;
}

void Sssssnake::MoveSnake() {
	GetKey();
	CalcTail();
	switch(eDirection) {
	case UP:
		if(HeadPosY == 0) {
			HeadPosY = HEIGHT-1;
		} else {
			HeadPosY = (HeadPosY-1) % HEIGHT;
		}
		break;
	case LEFT:
		if(HeadPosX == 0) {
			HeadPosX = WIDTH-1;
		} else {
			HeadPosX = (HeadPosX-1) % WIDTH;
		}
		break;
	case DOWN:
		HeadPosY = (HeadPosY+1) % HEIGHT;
		break;
	case RIGHT:
		HeadPosX = (HeadPosX+1) % WIDTH;
		break;
	default:
		break;
	}
}

void Sssssnake::AddTail() {
	TailNumber++;
	TailX[TailNumber] = TailX[TailNumber-1];
	TailY[TailNumber] = TailY[TailNumber-1];
}

void Sssssnake::GetKey() {
	switch(XGpio_DiscreteRead(&gpio1, 1)){
	case 1:
		if(eDirection != DOWN) {
			eDirection = UP;
		}
		break;
	case 2:
		if(eDirection != RIGHT) {
			eDirection = LEFT;
		}
		break;
	case 8:
		if(eDirection != UP) {
			eDirection = DOWN;
		}
		break;
	case 4:
		if(eDirection != LEFT) {
			eDirection = RIGHT;
		}
		break;
	default:
		break;
	}
}

void Sssssnake::CalcTail() {
	for(uint8_t i = TailNumber; i > 0; i--) {
		TailX[i] = TailX[i-1];
		TailY[i] = TailY[i-1];
	}
	TailX[0] = HeadPosX;
	TailY[0] = HeadPosY;
}

bool Sssssnake::bCheckIfTailHit() {
	for(uint8_t i = 0; i < TailNumber; i++) {
		if(TailX[i] == HeadPosX && TailY[i] == HeadPosY) {
			return true;
		}
	}
	return false;
}

bool Sssssnake::bCheckIfSnakeOnPoint(u32 X, u32 Y) {
	if(HeadPosX == X && HeadPosY == Y) {
		return true;
	}
	for(uint8_t i = 0; i < TailNumber; i++) {
		if(TailX[i] == X && TailY[i] == Y) {
			return true;
		}
	}
	return false;
}
