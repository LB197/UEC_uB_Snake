#ifndef SNAKE_H_
#define SNAKE_H_
#include "xil_types.h"

enum Direction{UP, LEFT, DOWN, RIGHT};

class Sssssnake {
public:
	u32 HeadPosX;
	u32 HeadPosY;
	enum Direction eDirection;
	u32 TailX[16];
	u32 TailY[16];
	u32 TailNumber;

	Sssssnake();
	void MoveSnake();
	bool bCheckIfTailHit();
	bool bCheckIfSnakeOnPoint(u32 X, u32 Y);
	void AddTail();
	void CalcTail();
	void GetKey();
};

#endif /* SNAKE_H_ */
