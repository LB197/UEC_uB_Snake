#include "vga.h"
#include "xil_io.h"
#include "xparameters.h"

void VGA_SetBackgroundColor(u16 Color) {

	Xil_Out16(XPAR_VGA_BACKGROUND_0_S00_AXI_BG_BASEADDR, Color);
}

void VGA_DrawRectangle(u16 ObjectID, u64 Width, u64 Height, u64 Y, u64 X) {

	Xil_Out64(XPAR_VGA_DRAWRECT_0_S00_AXI_BASEADDR+(16*ObjectID), ((1ULL << 48) + (Width << 36) + (Height << 24) + (Y << 12) + X));
}

void VGA_DeleteRectangle(u16 ObjectID) {

	Xil_Out64(XPAR_VGA_DRAWRECT_0_S00_AXI_BASEADDR+(16*ObjectID), 0ULL);
}
