#include "xintc.h"
//#include "xintc_l.h"
//#include "xintc_i.h"
//#include "xil_exception.h"
#include "xgpio.h"
#include "xparameters.h"
#include "vga.h"
#include "xil_printf.h"

//void irq(void *CallbackRef);

XGpio gpio0, gpio1;
//XIntc intc;
u32 sw;

int main()
{
	XGpio_Initialize(&gpio0, XPAR_GPIO_0_DEVICE_ID);
	XGpio_Initialize(&gpio1, XPAR_GPIO_1_DEVICE_ID);

	XGpio_SetDataDirection(&gpio0, 2, 0x00000000); // set LED GPIO channel to All Output
	XGpio_SetDataDirection(&gpio0, 1, 0xFFFFFFFF); // set SW GPIO channel to All Input
	XGpio_SetDataDirection(&gpio1, 1, 0xFFFFFFFF); // set BTN GPIO channel to All Input
	VGA_SetBackgroundColor(0xF00);
	while (1) {

		VGA_DrawRectangle(0, 10, 10, 10, 20);
		VGA_DrawRectangle(1, 10, 10, 10, 30);
		VGA_DrawRectangle(2, 10, 10, 10, 40);
		VGA_DrawRectangle(3, 10, 10, 10, 50);
		VGA_DrawRectangle(4, 10, 10, 10, 60);
		VGA_DrawRectangle(5, 10, 10, 10, 70);
		VGA_DrawRectangle(6, 10, 10, 10, 80);
		VGA_DrawRectangle(7, 10, 10, 10, 90);
		VGA_DrawRectangle(8, 10, 10, 10, 100);
		VGA_DrawRectangle(9, 10, 10, 10, 10);
		VGA_DrawRectangle(10, 10, 10, 20, 10);
		VGA_DrawRectangle(11, 10, 10, 30, 10);
		VGA_DrawRectangle(12, 10, 10, 40, 10);
		VGA_DrawRectangle(13, 10, 10, 50, 10);
		VGA_DrawRectangle(14, 10, 10, 60, 10);
		VGA_DrawRectangle(15, 10, 10, 70, 10);
		VGA_DrawRectangle(16, 10, 10, 80, 10);


	}
}
/*
void irq(void *CallbackRef) {
	XGpio_DiscreteWrite(&gpio0, 2, sw);
	XGpio_InterruptClear(&gpio1, XGPIO_IR_CH1_MASK);
}
	XGpio_InterruptEnable(&gpio1, XGPIO_IR_CH1_MASK);
	XGpio_InterruptGlobalEnable(&gpio1);

	XIntc_Initialize(&intc, XPAR_INTC_0_DEVICE_ID);
	XIntc_SelfTest(&intc);
	XIntc_Connect(&intc, XPAR_MICROBLAZE_0_AXI_INTC_AXI_GPIO_1_IP2INTC_IRPT_INTR, (XInterruptHandler)irq, (void*)0);
	XIntc_Start(&intc, XIN_REAL_MODE);
	XIntc_Enable(&intc, XPAR_INTC_0_DEVICE_ID);

	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)XIntc_InterruptHandler, &intc);
	Xil_ExceptionEnable();
*/
