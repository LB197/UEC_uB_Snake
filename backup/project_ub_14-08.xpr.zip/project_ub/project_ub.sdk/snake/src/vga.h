#ifndef SRC_VGA_H_
#define SRC_VGA_H_
#include "xbasic_types.h"
#include "xil_types.h"

void VGA_SetBackgroundColor(u16 Color);
void VGA_DrawRectangle(u16 ObjectID, u64 Width, u64 Height, u64 Y, u64 X);
void VGA_DeleteRectangle(u16 ObjectID);

#endif /* SRC_VGA_H_ */
